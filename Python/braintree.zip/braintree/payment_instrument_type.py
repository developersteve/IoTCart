
class PaymentInstrumentType():
    PayPalAccount = "paypal_account"
    SEPABankAccount = "sepa_bank_account"
    CreditCard = "credit_card"
    ApplePayCard = "apple_pay_card"
