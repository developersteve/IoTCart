from braintree.attribute_getter import AttributeGetter

class RiskData(AttributeGetter):
    pass
